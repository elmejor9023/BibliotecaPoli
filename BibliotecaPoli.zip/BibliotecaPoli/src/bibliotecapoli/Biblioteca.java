package bibliotecapoli;

import java.util.ArrayList;

public class Biblioteca {

    ArrayList<Libro> libros = new ArrayList<>();

    /* REGISTRAR */

    public void registrarLibro(Libro libro) {

        libros.add(libro);

        System.out.println("Libro registrado correctamente.");
    }

    /* MOSTRAR INVENTARIO */

    public void mostrarInventario() {

        if (libros.isEmpty()) {

            System.out.println("No hay libros registrados.");
            return;
        }

        for (Libro libro : libros) {

            libro.mostrarInfo();
        }
    }

    /* ACTUALIZAR STOCK */

    public void actualizarStock(String isbn, int nuevoStock) {

        for (Libro libro : libros) {

            if (libro.isbn.equals(isbn)) {

                libro.stock = nuevoStock;

                System.out.println("Stock actualizado.");
                return;
            }
        }

        System.out.println("Libro no encontrado.");
    }

    /* BUSCAR LIBRO */

    public void buscarLibro(String texto) {

        boolean encontrado = false;

        for (Libro libro : libros) {

            if (
                libro.titulo.toLowerCase().contains(texto.toLowerCase())
                || libro.autor.toLowerCase().contains(texto.toLowerCase())
                || libro.isbn.toLowerCase().contains(texto.toLowerCase())
            ) {

                libro.mostrarInfo();
                encontrado = true;
            }
        }

        if (!encontrado) {

            System.out.println("No se encontraron libros.");
        }
    }

    /* SACAR LIBRO */

    public void sacarLibro(String isbn, int cantidad) {

        for (Libro libro : libros) {

            if (libro.isbn.equals(isbn)) {

                if (cantidad > libro.stock) {

                    System.out.println("No hay suficiente stock.");
                    return;
                }

                libro.stock -= cantidad;

                System.out.println("Libro prestado correctamente.");
                return;
            }
        }

        System.out.println("Libro no encontrado.");
    }

    /* REPORTES */

    public void reporteBajoStock() {

        for (Libro libro : libros) {

            if (libro.stock <= 3) {

                libro.mostrarInfo();
            }
        }
    }

    public void libroMayorStock() {

        if (libros.isEmpty()) {

            System.out.println("No hay libros.");
            return;
        }

        Libro mayor = libros.get(0);

        for (Libro libro : libros) {

            if (libro.stock > mayor.stock) {

                mayor = libro;
            }
        }

        System.out.println("Libro con mayor stock:");

        mayor.mostrarInfo();
    }

    public void libroMenorStock() {

        if (libros.isEmpty()) {

            System.out.println("No hay libros.");
            return;
        }

        Libro menor = libros.get(0);

        for (Libro libro : libros) {

            if (libro.stock < menor.stock) {

                menor = libro;
            }
        }

        System.out.println("Libro con menor stock:");

        menor.mostrarInfo();
    }

    /* REPORTE NOVEDADES */

    public void crearReporte(String isbn, String mensaje) {

        System.out.println("\n========== REPORTE ==========");
        System.out.println("ISBN: " + isbn);
        System.out.println("Novedad: " + mensaje);
        System.out.println("=============================");
    }
}
