package bibliotecapoli;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        Biblioteca biblioteca = new Biblioteca();

        int opcion;

        do {

            System.out.println("\n=================================");
            System.out.println("       BIBLIOTECA POLI");
            System.out.println("=================================");
            System.out.println("1. Registrar libro");
            System.out.println("2. Actualizar stock");
            System.out.println("3. Consultar inventario");
            System.out.println("4. Reporte bajo stock");
            System.out.println("5. Libro con mayor stock");
            System.out.println("6. Libro con menor stock");
            System.out.println("7. Buscar libro");
            System.out.println("8. Sacar libro");
            System.out.println("9. Reporte de novedades");
            System.out.println("10. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = entrada.nextInt();
            entrada.nextLine();

            switch (opcion) {

                case 1:

                    System.out.print("Ingrese título: ");
                    String titulo = entrada.nextLine();

                    System.out.print("Ingrese autor: ");
                    String autor = entrada.nextLine();

                    System.out.print("Ingrese ISBN: ");
                    String isbn = entrada.nextLine();

                    System.out.print("Ingrese stock: ");
                    int stock = entrada.nextInt();

                    System.out.print("Ingrese precio: ");
                    double precio = entrada.nextDouble();

                    Libro nuevoLibro = new Libro(
                            titulo,
                            autor,
                            isbn,
                            stock,
                            precio
                    );

                    biblioteca.registrarLibro(nuevoLibro);

                    break;

                case 2:

                    System.out.print("Ingrese ISBN del libro: ");
                    String isbnBuscar = entrada.nextLine();

                    System.out.print("Ingrese nuevo stock: ");
                    int nuevoStock = entrada.nextInt();

                    biblioteca.actualizarStock(isbnBuscar, nuevoStock);

                    break;

                case 3:

                    biblioteca.mostrarInventario();

                    break;

                case 4:

                    biblioteca.reporteBajoStock();

                    break;

                case 5:

                    biblioteca.libroMayorStock();

                    break;

                case 6:

                    biblioteca.libroMenorStock();

                    break;

                case 7:

                    System.out.print("Ingrese título, autor o ISBN: ");

                    String texto = entrada.nextLine();

                    biblioteca.buscarLibro(texto);

                    break;

                case 8:

                    System.out.print("Ingrese ISBN del libro: ");

                    String isbnPrestamo = entrada.nextLine();

                    System.out.print("Ingrese cantidad: ");

                    int cantidad = entrada.nextInt();

                    biblioteca.sacarLibro(isbnPrestamo, cantidad);

                    break;

                case 9:

                    System.out.print("Ingrese ISBN del libro: ");

                    String isbnReporte = entrada.nextLine();

                    System.out.print("Ingrese novedad: ");

                    String mensaje = entrada.nextLine();

                    biblioteca.crearReporte(isbnReporte, mensaje);

                    break;

                case 10:

                    System.out.println("Gracias por usar BibliotecaPoli.");

                    break;

                default:

                    System.out.println("Opción inválida.");
            }

        } while (opcion != 10);
    }
}