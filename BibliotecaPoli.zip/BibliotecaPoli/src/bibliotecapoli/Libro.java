package bibliotecapoli;

public class Libro {

    public String titulo;
    public String autor;
    public String isbn;
    public int stock;
    public double precio;

    public Libro(String titulo, String autor, String isbn, int stock, double precio) {

        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.stock = stock;
        this.precio = precio;
    }

    public void mostrarInfo() {

        System.out.println("--------------------------------");
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("ISBN: " + isbn);
        System.out.println("Stock: " + stock);
        System.out.println("Precio: $" + precio);
    }
}
